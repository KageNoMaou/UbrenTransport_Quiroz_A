export interface Iconductores{
    id:number;
    nombre:string;
    apellido: string    
}

export interface Iconductor{
    nombre:string;
    apellido: string
}
export interface conductor{
    id: number;
    username:string;
    password:string;
    isactive: boolean
}
