import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Iconductores } from '../interface/interfaces';
import { environment } from 'src/environments/environment';
import { Iconductor } from '../interface/interfaces';

@Injectable({
  providedIn: 'root'
})
export class CrudServiceService {

  constructor(private httpClient: HttpClient) { }

  BuscarConductorId(id:number):Observable<Iconductores>{
    return this.httpClient.get<Iconductores>(`${environment.apiUrl}/conductor/?id=${id}`);
  }
  EliminarConductorId(id:number):Observable<Iconductores>{
    return this.httpClient.delete<Iconductores>(`${environment.apiUrl}/conductor${id}`);
  }

}
