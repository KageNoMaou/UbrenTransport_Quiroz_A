import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Iconductores, conductor } from '../interface/interfaces';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor( private httpClient: HttpClient) { }
  GetAllConductores():Observable<Iconductores>{
    return this.httpClient.get<Iconductores>(`${environment.apiUrl}`)
  }

  GetUserById(codigo: any):Observable<conductor>{
    return this.httpClient.get<conductor>(`${environment.apiUrl}/conductor/?username=${codigo}`);
  }

  IsLogged(){
    return sessionStorage.getItem('username')!=null;
  }
}
