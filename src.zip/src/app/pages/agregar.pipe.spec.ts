import { AgregarPipe } from './agregar.pipe';

describe('AgregarPipe', () => {
  it('create an instance', () => {
    const pipe = new AgregarPipe();
    expect(pipe).toBeTruthy();
  });
});
