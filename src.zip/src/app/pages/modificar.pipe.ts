import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'modificar'
})
export class ModificarPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
