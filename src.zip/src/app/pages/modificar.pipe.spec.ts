import { ModificarPipe } from './modificar.pipe';

describe('ModificarPipe', () => {
  it('create an instance', () => {
    const pipe = new ModificarPipe();
    expect(pipe).toBeTruthy();
  });
});
