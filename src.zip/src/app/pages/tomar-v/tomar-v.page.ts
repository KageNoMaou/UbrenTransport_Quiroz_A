import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tomar-v',
  templateUrl: './tomar-v.page.html',
  styleUrls: ['./tomar-v.page.scss'],
})
export class TomarVPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
