import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TomarVPageRoutingModule } from './tomar-v-routing.module';

import { TomarVPage } from './tomar-v.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TomarVPageRoutingModule
  ],
  declarations: [TomarVPage]
})
export class TomarVPageModule {}
