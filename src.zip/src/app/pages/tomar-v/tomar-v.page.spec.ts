import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TomarVPage } from './tomar-v.page';

describe('TomarVPage', () => {
  let component: TomarVPage;
  let fixture: ComponentFixture<TomarVPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(TomarVPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
