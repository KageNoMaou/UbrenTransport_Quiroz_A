import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CrudServiceService } from 'src/app/servicios/crud-service.service';

@Component({
  selector: 'app-eliminar',
  templateUrl: './eliminar.page.html',
  styleUrls: ['./eliminar.page.scss'],
})
export class EliminarPage implements OnInit {

  conductor={
    id:0,
    username:"",
    password:""
  }


  constructor(private router: Router,
              private crudService: CrudServiceService) { }

  ngOnInit() {
  }

  ionViewWillEnter(){
    this.getConductorById(this.getIdFromUrl());
  }

  getIdFromUrl(){
    let url=this.router.url;
    let arr=url.split("/",3);
    let id = parseInt(arr[3]);
    return id;
  }

  getConductorById(ConductorId: number){
    this.crudService.BuscarConductorId(ConductorId).subscribe(
      (resp:any)=>{
        this.conductor={
          id: resp[0].id,
          username: resp[0].username,
          password: resp[0].password
        }
      }

    )
  }

  eliminarConductor(){
    this.crudService.EliminarConductorId(this.conductor).subscribe();
    this.router.navigateByUrl("TomarV");
  }


}
